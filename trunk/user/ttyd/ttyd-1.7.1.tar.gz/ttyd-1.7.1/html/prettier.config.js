module.exports = {
    trailingComma: "es5",
    tabWidth: 4,
    printWidth: 120,
    singleQuote: true,
};
